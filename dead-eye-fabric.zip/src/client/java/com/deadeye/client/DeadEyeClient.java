package com.deadeye.client;

import net.fabricmc.api.ClientModInitializer;

public class DeadEyeClient implements ClientModInitializer {
	@Override
	public void onInitialize() {
		// Stage 2: OBJ gun renderer + sepia Dead Eye overlay go here.
	}
}
