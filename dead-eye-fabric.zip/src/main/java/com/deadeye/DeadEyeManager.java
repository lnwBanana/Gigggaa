package com.deadeye;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Dead Eye logic (server side).
 *
 * Right-click          : fire one shot (empty gun = reload)
 * Hold sneak ~0.3 s    : enter Dead Eye (server tick rate drops)
 * Right-click in DE    : place a mark (auto head-lock near heads)
 * Release sneak        : unleash all marks as rapid fire
 */
public final class DeadEyeManager {
	// ---- tuning ----
	static final float SLOW_TPS = 8f;
	static final float NORMAL_TPS = 20f;
	static final double RANGE = 64;
	static final int ENTER_TICKS = 6;
	static final float MAX_ENERGY = 100f;
	static final float MIN_ENERGY = 10f;
	static final float DRAIN_PER_TICK = 1.5f;   // at slow tps (~8 s of Dead Eye)
	static final float REGEN_PER_TICK = 0.33f;  // at 20 tps (~15 s to refill)
	static final float KILL_BONUS = 18f;
	static final float HEAD_DAMAGE = 16f;
	static final float BODY_DAMAGE = 8f;
	static final float QUICK_HEAD_DAMAGE = 12f;
	static final float QUICK_BODY_DAMAGE = 6f;
	static final int SHOT_DELAY = 3;
	static final int QUICK_COOLDOWN = 8;
	static final int RELOAD_STEP = 6;
	static final double SNAP_ANGLE = 0.11; // radians, head lock cone

	private static final Map<UUID, State> STATES = new HashMap<>();

	static final class Mark {
		LivingEntity entity;
		boolean head;
		Vec3 off;
		Vec3 pos;

		Vec3 now() {
			if (entity != null) {
				if (!entity.isAlive()) return null;
				if (head) return new Vec3(entity.getX(), entity.getEyeY(), entity.getZ());
				return entity.position().add(off);
			}
			return pos;
		}
	}

	static final class State {
		int sneak;
		boolean active;
		int t;
		int cool;
		float energy = MAX_ENERGY;
		final List<Mark> marks = new ArrayList<>();
		final ArrayDeque<Mark> pending = new ArrayDeque<>();
		int shotTimer;
		int reloadLeft;
		int reloadTimer;
	}

	private static State state(ServerPlayer p) {
		return STATES.computeIfAbsent(p.getUUID(), k -> new State());
	}

	private static ItemStack heldGun(ServerPlayer p) {
		ItemStack s = p.getMainHandItem();
		return s.getItem() instanceof RevolverItem ? s : null;
	}

	// ======================= events =======================

	public static void onUse(ServerLevel level, ServerPlayer p, ItemStack gun) {
		State s = state(p);
		if (s.active) {
			placeMark(level, p, s, gun);
			return;
		}
		if (s.cool > 0 || s.reloadLeft > 0) return;
		int rounds = RevolverItem.rounds(gun);
		boolean offhandAmmo = p.getOffhandItem().is(DeadEyeItems.AMMO);
		if (rounds <= 0 || (rounds < RevolverItem.MAX_ROUNDS && offhandAmmo)) {
			startReload(level, p, s, gun);
			return;
		}
		quickShot(level, p, s, gun);
	}

	public static void onKill(LivingEntity killed, DamageSource source) {
		Entity killer = source.getEntity();
		if (killer instanceof ServerPlayer sp) {
			State s = STATES.get(sp.getUUID());
			if (s != null) s.energy = Math.min(MAX_ENERGY, s.energy + KILL_BONUS);
		}
	}

	public static void onLeave(ServerPlayer p, MinecraftServer server) {
		State s = STATES.remove(p.getUUID());
		if (s != null && s.active) restoreSpeedIfIdle(server);
	}

	public static void reset(MinecraftServer server) {
		STATES.clear();
		server.tickRateManager().setTickRate(NORMAL_TPS);
	}

	// ======================= tick =======================

	public static void tick(MinecraftServer server) {
		for (ServerPlayer p : server.getPlayerList().getPlayers()) {
			State s = state(p);
			if (s.cool > 0) s.cool--;
			ItemStack gun = heldGun(p);

			if (!s.pending.isEmpty() && --s.shotTimer <= 0) {
				fireMark(p, s, s.pending.poll());
				s.shotTimer = SHOT_DELAY;
			}

			if (s.reloadLeft > 0 && --s.reloadTimer <= 0) {
				if (gun != null && RevolverItem.rounds(gun) < RevolverItem.MAX_ROUNDS) {
					RevolverItem.setRounds(gun, RevolverItem.rounds(gun) + 1);
					play(p, SoundEvents.LEVER_CLICK, 0.7f, 1.2f + (RevolverItem.MAX_ROUNDS - s.reloadLeft) * 0.06f);
				}
				s.reloadLeft--;
				s.reloadTimer = RELOAD_STEP;
			}

			if (gun == null) {
				if (s.active) endDeadEye(server, p, s, false);
				s.sneak = 0;
				s.energy = Math.min(MAX_ENERGY, s.energy + REGEN_PER_TICK);
				continue;
			}

			s.sneak = p.isShiftKeyDown() ? s.sneak + 1 : 0;
			if (!s.active) {
				s.energy = Math.min(MAX_ENERGY, s.energy + REGEN_PER_TICK);
				if (s.sneak >= ENTER_TICKS && RevolverItem.rounds(gun) > 0 && s.energy >= MIN_ENERGY
					&& s.pending.isEmpty() && s.reloadLeft == 0) {
					startDeadEye(server, p, s);
				}
			} else {
				s.energy -= DRAIN_PER_TICK;
				if (!p.isShiftKeyDown() || s.energy <= 0 || RevolverItem.rounds(gun) <= 0) {
					endDeadEye(server, p, s, true);
				} else {
					s.t++;
					ServerLevel level = p.level() instanceof ServerLevel sl ? sl : null;
					if (level != null) drawMarks(level, p, s);
					if (s.t % 5 == 0) play(p, SoundEvents.WARDEN_HEARTBEAT, 0.6f, 0.7f);
				}
			}
			hud(p, s, gun);
		}
	}

	// ======================= dead eye =======================

	private static void startDeadEye(MinecraftServer server, ServerPlayer p, State s) {
		s.active = true;
		s.t = 0;
		s.marks.clear();
		server.tickRateManager().setTickRate(SLOW_TPS);
		play(p, SoundEvents.BEACON_ACTIVATE, 0.7f, 0.5f);
		play(p, SoundEvents.WARDEN_HEARTBEAT, 0.9f, 0.8f);
	}

	private static void endDeadEye(MinecraftServer server, ServerPlayer p, State s, boolean fire) {
		s.active = false;
		restoreSpeedIfIdle(server);
		play(p, SoundEvents.BEACON_DEACTIVATE, 0.6f, 0.7f);
		if (fire && !s.marks.isEmpty()) {
			s.pending.addAll(s.marks);
			s.shotTimer = 1;
		}
		s.marks.clear();
	}

	private static void restoreSpeedIfIdle(MinecraftServer server) {
		for (State o : STATES.values()) if (o.active) return;
		server.tickRateManager().setTickRate(NORMAL_TPS);
	}

	private static void placeMark(ServerLevel level, ServerPlayer p, State s, ItemStack gun) {
		if (s.marks.size() >= RevolverItem.rounds(gun)) {
			p.displayClientMessage(Component.literal("\u00a7eAll chambers marked"), true);
			return;
		}
		Mark m = findTarget(level, p);
		if (m == null) return;
		s.marks.add(m);
		play(p, SoundEvents.DISPENSER_FAIL, 0.8f, 1.6f);
	}

	private static void drawMarks(ServerLevel level, ServerPlayer p, State s) {
		for (Mark m : s.marks) {
			Vec3 c = m.now();
			if (c != null) drawX(level, p, c, m.head);
		}
	}

	private static void drawX(ServerLevel level, ServerPlayer p, Vec3 c, boolean head) {
		Vec3 look = p.getLookAngle();
		Vec3 r = look.cross(new Vec3(0, 1, 0));
		r = r.lengthSqr() < 1e-4 ? new Vec3(1, 0, 0) : r.normalize();
		Vec3 u = r.cross(look).normalize();
		double size = head ? 0.30 : 0.22;
		DustParticleOptions dust = new DustParticleOptions(head ? 0xFF0000 : 0xFF3030, 1.1f);
		for (int i = -3; i <= 3; i++) {
			double k = size * i / 3.0;
			Vec3 a = c.add(r.scale(k)).add(u.scale(k));
			Vec3 b = c.add(r.scale(k)).subtract(u.scale(k));
			level.sendParticles(dust, a.x, a.y, a.z, 1, 0, 0, 0, 0);
			level.sendParticles(dust, b.x, b.y, b.z, 1, 0, 0, 0, 0);
		}
	}

	// ======================= targeting =======================

	private static boolean valid(LivingEntity e, ServerPlayer p) {
		return e != p && e.isAlive() && !(e instanceof Player) && !(e instanceof ArmorStand);
	}

	private static Mark findTarget(ServerLevel level, ServerPlayer p) {
		Vec3 eye = p.getEyePosition();
		Vec3 look = p.getLookAngle();
		Vec3 end = eye.add(look.scale(RANGE));

		BlockHitResult bh = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
		boolean blockHit = bh.getType() != HitResult.Type.MISS;
		double blockDist = blockHit ? bh.getLocation().distanceTo(eye) : RANGE;

		// 1) direct crosshair hit
		AABB area = p.getBoundingBox().expandTowards(look.scale(RANGE)).inflate(1.0);
		LivingEntity best = null;
		Vec3 bestHit = null;
		double bestD = blockDist;
		for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, area, x -> valid(x, p))) {
			Optional<Vec3> h = e.getBoundingBox().inflate(0.1).clip(eye, end);
			if (h.isPresent()) {
				double d = h.get().distanceTo(eye);
				if (d < bestD) { bestD = d; best = e; bestHit = h.get(); }
			}
		}
		if (best != null) {
			Mark m = new Mark();
			m.entity = best;
			if (bestHit.y > best.getEyeY() - 0.3) m.head = true;
			else m.off = bestHit.subtract(best.position());
			return m;
		}

		// 2) head lock: aim assist cone
		LivingEntity cand = null;
		double bestAng = SNAP_ANGLE;
		for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(RANGE), x -> valid(x, p))) {
			Vec3 head = new Vec3(e.getX(), e.getEyeY(), e.getZ());
			Vec3 to = head.subtract(eye);
			double dist = to.length();
			if (dist < 1.5 || dist > RANGE) continue;
			double ang = Math.acos(Math.max(-1, Math.min(1, to.normalize().dot(look))));
			if (ang < bestAng) {
				BlockHitResult c = level.clip(new ClipContext(eye, head, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
				if (c.getType() == HitResult.Type.MISS || c.getLocation().distanceTo(eye) > dist - 0.6) {
					cand = e;
					bestAng = ang;
				}
			}
		}
		if (cand != null) {
			Mark m = new Mark();
			m.entity = cand;
			m.head = true;
			return m;
		}

		// 3) plain block point
		if (blockHit) {
			Mark m = new Mark();
			m.pos = bh.getLocation();
			return m;
		}
		return null;
	}

	// ======================= shooting =======================

	private static void quickShot(ServerLevel level, ServerPlayer p, State s, ItemStack gun) {
		s.cool = QUICK_COOLDOWN;
		Mark t = findTarget(level, p);
		Vec3 target = p.getEyePosition().add(p.getLookAngle().scale(RANGE));
		LivingEntity victim = null;
		float dmg = 0;
		if (t != null) {
			Vec3 now = t.now();
			if (now != null) target = now;
			if (t.entity != null) {
				victim = t.entity;
				dmg = t.head ? QUICK_HEAD_DAMAGE : QUICK_BODY_DAMAGE;
			}
		}
		RevolverItem.setRounds(gun, RevolverItem.rounds(gun) - 1);
		shoot(level, p, target, victim, dmg, t != null && t.head);
	}

	private static void fireMark(ServerPlayer p, State s, Mark m) {
		ItemStack gun = heldGun(p);
		if (gun == null || RevolverItem.rounds(gun) <= 0 || !(p.level() instanceof ServerLevel level)) {
			s.pending.clear();
			return;
		}
		Vec3 pos = m.now();
		if (pos == null) return; // target died, no round wasted
		RevolverItem.setRounds(gun, RevolverItem.rounds(gun) - 1);
		shoot(level, p, pos, m.entity, m.head ? HEAD_DAMAGE : BODY_DAMAGE, m.head);
	}

	private static Vec3 muzzle(ServerPlayer p) {
		Vec3 look = p.getLookAngle();
		Vec3 r = look.cross(new Vec3(0, 1, 0));
		r = r.lengthSqr() < 1e-4 ? new Vec3(1, 0, 0) : r.normalize();
		return p.getEyePosition().add(look.scale(1.0)).add(r.scale(0.25)).add(0, -0.2, 0);
	}

	private static void shoot(ServerLevel level, ServerPlayer p, Vec3 target, LivingEntity victim, float dmg, boolean head) {
		Vec3 from = muzzle(p);
		Vec3 v = target.subtract(from);
		double len = v.length();
		Vec3 dir = len > 1e-4 ? v.scale(1 / len) : p.getLookAngle();
		for (double d = 0.6; d < len && d < 72; d += 0.9) {
			Vec3 q = from.add(dir.scale(d));
			level.sendParticles(ParticleTypes.END_ROD, q.x, q.y, q.z, 1, 0, 0, 0, 0);
		}
		level.sendParticles(ParticleTypes.FLAME, from.x, from.y, from.z, 4, 0.04, 0.04, 0.04, 0.02);
		level.sendParticles(ParticleTypes.SMOKE, from.x, from.y, from.z, 3, 0.05, 0.05, 0.05, 0.01);
		level.playSound(null, from.x, from.y, from.z, SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.PLAYERS, 1.2f, 0.7f);
		level.playSound(null, from.x, from.y, from.z, SoundEvents.FIREWORK_ROCKET_LARGE_BLAST, SoundSource.PLAYERS, 0.7f, 1.6f);

		if (victim != null && victim.isAlive() && dmg > 0) {
			victim.invulnerableTime = 0;
			victim.hurtServer(level, level.damageSources().playerAttack(p), dmg);
			level.sendParticles(ParticleTypes.CRIT, target.x, target.y, target.z, 8, 0.15, 0.15, 0.15, 0.2);
			if (head) {
				level.playSound(null, target.x, target.y, target.z, SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.8f, 0.6f);
			}
		} else {
			level.sendParticles(ParticleTypes.SMOKE, target.x, target.y, target.z, 3, 0.05, 0.05, 0.05, 0.01);
		}
	}

	// ======================= reload =======================

	private static void startReload(ServerLevel level, ServerPlayer p, State s, ItemStack gun) {
		int need = RevolverItem.MAX_ROUNDS - RevolverItem.rounds(gun);
		if (need <= 0) return;
		int got = takeAmmo(p, need);
		if (got <= 0) {
			play(p, SoundEvents.DISPENSER_FAIL, 0.6f, 0.5f);
			p.displayClientMessage(Component.literal("\u00a7cNo rounds"), true);
			return;
		}
		s.reloadLeft = got;
		s.reloadTimer = 4;
	}

	private static int takeAmmo(ServerPlayer p, int want) {
		if (p.getAbilities().instabuild) return want;
		Inventory inv = p.getInventory();
		int got = 0;
		for (int i = 0; i < inv.getContainerSize() && got < want; i++) {
			ItemStack st = inv.getItem(i);
			if (st.is(DeadEyeItems.AMMO)) {
				int t = Math.min(st.getCount(), want - got);
				st.shrink(t);
				got += t;
			}
		}
		return got;
	}

	// ======================= helpers =======================

	private static void play(ServerPlayer p, SoundEvent ev, float vol, float pitch) {
		p.level().playSound(null, p.getX(), p.getY(), p.getZ(), ev, SoundSource.PLAYERS, vol, pitch);
	}

	private static void hud(ServerPlayer p, State s, ItemStack gun) {
		if (p.tickCount % 2 != 0) return;
		int r = RevolverItem.rounds(gun);
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < RevolverItem.MAX_ROUNDS; i++) sb.append(i < r ? "\u00a76\u25cf " : "\u00a78\u25cb ");
		int bars = Math.round(s.energy / MAX_ENERGY * 10);
		sb.append("  \u00a77DEAD EYE \u00a7c");
		for (int i = 0; i < 10; i++) sb.append(i < bars ? "\u25ae" : "\u00a78\u25ae\u00a7c");
		if (s.active) sb.append("  \u00a74X\u00d7").append(s.marks.size());
		p.displayClientMessage(Component.literal(sb.toString()), true);
	}

	private DeadEyeManager() {
	}
}
