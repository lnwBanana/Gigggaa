package com.deadeye;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DeadEyeMod implements ModInitializer {
	public static final String MOD_ID = "dead_eye";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		DeadEyeItems.init();
		ServerTickEvents.END_SERVER_TICK.register(DeadEyeManager::tick);
		ServerLivingEntityEvents.AFTER_DEATH.register(DeadEyeManager::onKill);
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> DeadEyeManager.onLeave(handler.getPlayer(), server));
		ServerLifecycleEvents.SERVER_STOPPING.register(DeadEyeManager::reset);
		LOGGER.info("Dead Eye Revolver loaded");
	}
}
