package com.deadeye;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Rounds are stored as durability: rounds = MAX_ROUNDS - damage. */
public class RevolverItem extends Item {
	public static final int MAX_ROUNDS = 5;

	public RevolverItem(Properties properties) {
		super(properties);
	}

	public static int rounds(ItemStack stack) {
		return MAX_ROUNDS - stack.getDamageValue();
	}

	public static void setRounds(ItemStack stack, int n) {
		stack.setDamageValue(MAX_ROUNDS - Math.max(0, Math.min(MAX_ROUNDS, n)));
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		if (hand == InteractionHand.MAIN_HAND && level instanceof ServerLevel serverLevel && player instanceof ServerPlayer sp) {
			DeadEyeManager.onUse(serverLevel, sp, player.getItemInHand(hand));
		}
		return InteractionResult.SUCCESS;
	}
}
