package com.deadeye;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;

public final class DeadEyeItems {
	public static final ResourceKey<Item> REVOLVER_KEY = key("revolver");
	public static final ResourceKey<Item> AMMO_KEY = key("revolver_ammo");

	public static final Item REVOLVER = Registry.register(BuiltInRegistries.ITEM, REVOLVER_KEY,
		new RevolverItem(new Item.Properties().setId(REVOLVER_KEY).durability(RevolverItem.MAX_ROUNDS)));
	public static final Item AMMO = Registry.register(BuiltInRegistries.ITEM, AMMO_KEY,
		new Item(new Item.Properties().setId(AMMO_KEY)));

	private static ResourceKey<Item> key(String path) {
		return ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(DeadEyeMod.MOD_ID, path));
	}

	public static void init() {
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT).register(entries -> {
			entries.accept(REVOLVER);
			entries.accept(AMMO);
		});
	}

	private DeadEyeItems() {
	}
}
