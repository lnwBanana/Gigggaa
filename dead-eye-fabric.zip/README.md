# Dead Eye Revolver (Fabric, Minecraft 1.21.11)

## Build the .jar without a PC (GitHub Actions)
1. Create a GitHub repo, upload EVERYTHING in this folder (keep the .github folder).
2. Open the "Actions" tab -> the "build" workflow runs by itself.
3. When it turns green, open the run -> "Artifacts" -> download, unzip, take `dead_eye-0.1.0.jar`
   (NOT the -sources jar).
4. Put the jar in your launcher's mods folder together with Fabric Loader 0.20.1+ and Fabric API for 1.21.11.
If the run is red, open the log and send me the red error lines.

## Controls
- Right-click: shoot. Empty: reload from inventory (or hold ammo in offhand to top up)
- Hold Sneak ~0.3 s: Dead Eye (world slows to 8 tps)
- Right-click while in Dead Eye: place a red X (auto head-lock near heads)
- Release Sneak: all marks fire rapid-fire. Kills refill the bar.
- /give @s dead_eye:revolver, /give @s dead_eye:revolver_ammo 30
